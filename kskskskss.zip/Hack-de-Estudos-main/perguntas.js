criaCartao (
    'Programação',
    'Para que serve o main de uma pagina html?',
    'Serve para eu anexar todo conteúdo principal do meu site'
)

criaCartao (
    'Robótica',
    'Por que o carrinho de robótica não deu certo?',
    'Estava com mal contato no jumper que conectava na placa'
)

criaCartao (
    'História',
    'Quais foram algumas das principais revoltas que ocorreram durante a Primeira República do Brasil?',
    'Revolta das vacinas, revolta de canudos, revolução federalista, movimento do contestado.'
)

criaCartao (
    'Geografia',
    'Quais são as estações do ano ?',
    'Outono, Inverno, Verão, Primavera'
)

criaCartao (
    'Empreendedorismo',
    'O que é MEI?',
    'Microempreendedorismo individual '
)

criaCartao (
    'Empreendedorismo',
    'O que é receita recorrente?',
    'Fluxo continuo de faturamento gerado para a empresa'
)

criaCartao (
    'Empreendedorismo',
    'O que e previsibilidade?',
    'qualidade da pessoa que se comporta da forma como se espera'
)

criaCartao (
    'Empreendedorismo',
    'Quais são as vantagens de um negócio ser escalável?',
    'as empresa s adotam melhorias nos processos e conquistam mais credibilidade para a marca'
)

criaCartao (
    'Biologia',
    'Quais são os tipos de agrotóxicos?',
    'Inseticidas, fungicidas, herbicidas, esfoliantes e fumigantes'
)

criaCartao (
    'Biologia',
    'Qual o conceito de saúde?',
    'Um estado de completo bem-estar físico, mental e social, não apenas na ausência de doenças'
)


criaCartao (
    'Biologia',
    'O que são Heredogramas?',
    'São quase como árvores genealógicas, mas que focam em características específicas e como elas são transformadas de geração para geração da família',
)


criaCartao (
   'Biologia',
    'O que são vacinas?',
    'As vacinas são produtos biológicos que estimulam o organismo e se defender de invasores'
)

criaCartao (
    'química',
    'o que são amidas?',
    'Amidas são compostos orgânicos derivados de ácidos, onde o grupo hidroxila (–OH) é substituído por um grupo amino (–NH2).'
)

criaCartao (
   'química',
    'o que são aminas?',
    'Aminas são uma função ogânica em que o nitrogênio liga-se diretamente a um grupo acila.' 
)

criaCartao (
    'química',
    'o que significa o termo HPA?',
    'Hidrocarbonetos Policíclicos Aromáticos.'
)

criaCartao (
    'química',
    'como calcular o deltaH?',
    'deltaH=HP-HR.'
)

criaCartao (
    'química',
    'o que são ácidos carboxílicos',
    'São compostos orgẫnicos que possuem o grupo funcional  carboxila em sua estrutura.'
)

criaCartao (
    'química',
    'qual o significado da palavra Isomeria?',
    'Iso=igual Meria= partes.'
)

criaCartao (
    'quínica',
    'cite um exemplo de Fenol.',
    'Xilenol-(CH3)2 C6H3OH.'
)

criaCartao (
    'Emprendedorismo',
    'Características de um empreendedor de sucesso?',
    'Resiliência, adaptabilidade, visão, proatividade e boas habilidades de comunicação.'
)

criaCartao (
    'Emprendedorismo',
    'Como identificar uma oportunidade de negócio?',
   'Analise o mercado, identifique problemas e estude as necessidades dos clientes.'
)

criaCartao (
    'Emprendedorismo',
    'Passos para um plano de negócios?',
   'Inclua descrição do negócio, análise de mercado, plano de marketing e finanças.'
)

criaCartao (
    'Emprendedorismo',
    'Impacto do networking?',
    'Ajuda a fazer conexões, encontrar mentores e atrair investidores.'
)

criaCartao (
    'Emprendedorismo',
    'Desafios de novos empreendedores?',
    'Falta de capital, inexperiência e competição.'
)

criaCartao (
    'Emprendedorismo',
    'Como usar tecnologia para escalar?',
    'Automatize processos, use marketing digital e analise dados de clientes.'
)

criaCartao (
    'Empreendorismo',
    'Melhores práticas para fluxo de caixa?',
    'Monitore receitas e despesas, crie um orçamento e planeje pagamentos.'
)

criaCartao (
    'Empreendorismo',
    'Como lidar com fracasso?',
     'Aprenda com os erros, ajuste a abordagem e mantenha a resiliência.'
)